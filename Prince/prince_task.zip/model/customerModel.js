const mongoose = require('mongoose');


// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/e-comm", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("DB Connected");
}).catch((e) => {
    console.log("DB Connection Error:", e.message);
});

//  customer schema
const customerSchema = new mongoose.Schema({
    customerName: {
        type: String,
        required: true
    },
    customerSince: {
        type: Number,
        required: true
    }
});

const Customer = mongoose.model('Customer', customerSchema);


module.exports = Customer;
