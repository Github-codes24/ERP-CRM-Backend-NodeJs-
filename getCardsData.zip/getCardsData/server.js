// server.js
const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

const uri = 'mongodb://localhost:27017'; // For local MongoDB or MongoDB Atlas connection string
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

const dbName = 'customerDB';
const collectionName = 'customers';

// Sample data representing customers (in-memory)
let customers = [
  {
    id: 1,
    salesPerson: 'Anand',
    region: 'North/Delhi/South Delhi',
    organization: 'Latanangeshkar Hospital',
    quotationInName: 'Anand',
    name: 'Shubham',
    designation: 'HOD',
    specialty: 'Cardiologists'
  },
  {
    id: 2,
    salesPerson: 'Dhiraj',
    region: 'South/Tamil Nadu/Chennai',
    organization: 'Maxwell Hospital',
    quotationInName: 'Dhiraj',
    name: 'Rutuji',
    designation: 'HOD',
    specialty: 'Orthopedic'
  },
  // More customer objects here...
];

// Connect to MongoDB
async function connectToMongoDB() {
  try {
    await client.connect();
    console.log('Connected to MongoDB');
  } catch (err) {
    console.error('Error connecting to MongoDB:', err);
  }
}

// POST route to add a new customer
app.post('/newCustomer', async (req, res) => {
  const { salesPerson, region, organization, quotationInName, name, designation, specialty } = req.body;

  // Validate request body
  if (!salesPerson || !region || !organization || !quotationInName || !name || !designation || !specialty) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  // Create new customer object
  const newCustomer = {
    id: customers.length + 1,  // Auto increment ID
    salesPerson,
    region,
    organization,
    quotationInName,
    name,
    designation,
    specialty
  };

  // Add new customer to the in-memory array
  customers.push(newCustomer);

  // Save new customer to MongoDB
  try {
    const db = client.db(dbName);
    const collection = db.collection(collectionName);
    await collection.insertOne(newCustomer);
    res.status(201).json({
      message: 'New customer added successfully',
      customer: newCustomer
    });
  } catch (err) {
    console.error('Error saving to MongoDB:', err);
    res.status(500).json({ message: 'Error saving to MongoDB' });
  }
});

// GET request to fetch customer cards data
app.get('/getCardsData', async (req, res) => {
  try {
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    // Fetch all customer data
    const customers = await collection.find({}).toArray();

    // Structure the response
    const response = {
      totalCustomers: customers.length,
      activeCustomers: customers.filter(customer => customer.active).length,
      notApproached: customers.filter(customer => !customer.approached).length,
      customers: customers
    };

    res.json(response);
  } catch (err) {
    console.error('Error fetching data:', err);
    res.status(500).send('Error fetching data');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});

connectToMongoDB();
