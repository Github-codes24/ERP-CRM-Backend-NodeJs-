const express = require('express');

const Product = require('./model/productModel'); 
const Customer = require('./model/customerModel'); 

const app = express();
const PORT = 3000;



app.get('/api/top-products', async (req, res) => {
    try {
       
        const topProducts = await Product.find({})
            .sort({ popularity: -1,salesPercentage: -1, 
                projects: -1,      
                popularity: -1 }) 
            .limit(10);  

        res.status(200).json(topProducts);
    } catch (error) {
        console.error('Error fetching top products:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

app.get('/top-customers', async (req, res) => {
    try {
       
        const customers = await Customer.find().sort({
            customerSince: -1 
        }).limit(5);

        // Return the sorted customers
        res.status(200).json(customers);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
