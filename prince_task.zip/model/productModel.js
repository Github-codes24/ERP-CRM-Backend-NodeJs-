const mongoose = require('mongoose');


// Connect to MongoDB
mongoose.connect("mongodb://localhost:27017/e-comm", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("DB Connected");
}).catch((e) => {
    console.log("DB Connection Error:", e.message);
});


//  schema for Product
const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    salesPercentage: {
        type: Number,
        required: true
    },
    projects: {
        type: Number,
        required: true
    },
    popularity: {
        type: Number,
        required: true
    },
    price: {
        type: Number,
        required:true
    }
});

const Product = mongoose.model('products', productSchema);

module.exports = Product;
